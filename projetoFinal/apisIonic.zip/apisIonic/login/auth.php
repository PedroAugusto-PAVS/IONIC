<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include 'db.php';
require 'jwt.php';

// Registrar um novo usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_GET['action'] === 'register') {
    $data = json_decode(file_get_contents("php://input"));

    $nome = $data->nome;
    $email = $data->email;
    $senha = password_hash($data->senha, PASSWORD_BCRYPT);

    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("message" => "Usuário registrado com sucesso"));
    } else {
        echo json_encode(array("message" => "Erro ao registrar usuário"));
    }
}

// Autenticar o usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_GET['action'] === 'login') {
    $data = json_decode(file_get_contents("php://input"));

    $email = $data->email;
    $senha = $data->senha;

    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    if ($user && password_verify($senha, $user['senha'])) {
        $token = generate_jwt($user['id']);
        echo json_encode(array("message" => "Login bem-sucedido", "token" => $token));
    } else {
        echo json_encode(array("message" => "Credenciais inválidas"));
    }
}

$conn->close();
?>
