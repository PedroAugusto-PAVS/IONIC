<?php

function generate_jwt($user_id) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload = json_encode(['user_id' => $user_id, 'exp' => (time() + 3600)]); // Expira em 1 hora

    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

    $secret = 'chave_secreta';

    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    $jwt = $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
    
    return $jwt;
}

function is_jwt_valid($jwt) {
    $secret = 'chave_secreta';
    $jwt_parts = explode('.', $jwt);

    if (count($jwt_parts) !== 3) {
        return false;
    }

    list($header, $payload, $signature) = $jwt_parts;

    $payload_decoded = json_decode(base64_decode($payload), true);

    if ($payload_decoded['exp'] < time()) {
        return false; // O token expirou
    }

    $valid_signature = hash_hmac('sha256', $header . "." . $payload, $secret, true);
    $valid_signature_base64 = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($valid_signature));

    return ($signature === $valid_signature_base64);
}
?>
