<?php
$host = 'localhost';
$user = 'root';  
$password = '';  
$db_name = 'dmprojetofinal';

// Criar a conexão
$conn = new mysqli($host, $user, $password, $db_name);

// Checar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
