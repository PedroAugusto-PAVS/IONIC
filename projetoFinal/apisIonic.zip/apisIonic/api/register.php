<?php
include 'conexao.php';

header('Content-Type: application/json');

$email = $_POST['email'];
$senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);

$sql = 'INSERT INTO usuarios (email, senha) VALUES (?, ?)';
$stmt = $pdo->prepare($sql);

if ($stmt->execute([$email, $senha])) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
?>
