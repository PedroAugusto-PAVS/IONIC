<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include 'db.php';
require 'jwt.php';

// Verificar se o usuário está autenticado
$headers = apache_request_headers();
$jwt = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

if (!is_jwt_valid($jwt)) {
    echo json_encode(array("message" => "Acesso negado"));
    exit;
}

$user_id = json_decode(base64_decode(explode('.', $jwt)[1]))->user_id;

// Listar todos os itens do usuário autenticado
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sql = "SELECT * FROM itens WHERE user_id='$user_id'";
    $result = $conn->query($sql);
    $itens = array();

    while($row = $result->fetch_assoc()) {
        $itens[] = $row;
    }

    echo json_encode($itens);
}

// Adicionar um novo item
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    $nome = $data->nome;
    $quantidade = $data->quantidade;
    $preco = $data->preco;

    $sql = "INSERT INTO itens (nome, quantidade, preco, user_id) VALUES ('$nome', '$quantidade', '$preco', '$user_id')";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("message" => "Item adicionado com sucesso"));
    } else {
        echo json_encode(array("message" => "Erro ao adicionar item"));
    }
}

// Atualizar item existente
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents("php://input"));

    $id = $data->id;
    $nome = $data->nome;
    $quantidade = $data->quantidade;
    $preco = $data->preco;
    $adquirido = $data->adquirido;

    $sql = "UPDATE itens SET nome='$nome', quantidade='$quantidade', preco='$preco', adquirido='$adquirido' WHERE id='$id' AND user_id='$user_id'";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("message" => "Item atualizado com sucesso"));
    } else {
        echo json_encode(array("message" => "Erro ao atualizar item"));
    }
}

// Deletar item
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents("php://input"));

    $id = $data->id;

    $sql = "DELETE FROM itens WHERE id='$id' AND user_id='$user_id'";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(array("message" => "Item deletado com sucesso"));
    } else {
        echo json_encode(array("message" => "Erro ao deletar item"));
    }
}

$conn->close();
?>
