<?php
include 'conexao.php';

header('Content-Type: application/json');

$action = $_POST['action'];
$usuarios_id = $_POST['usuarios_id'];

if ($action === 'list') {
    $sql = 'SELECT * FROM itens WHERE usuarios_id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuarios_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($itens);
} elseif ($action === 'add') {
    $nome = $_POST['nome'];
    $quantidade = $_POST['quantidade'];
    $preco = $_POST['preco'];

    $sql = 'INSERT INTO itens (nome, quantidade, preco, usuarios_id) VALUES (?, ?, ?, ?)';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nome, $quantidade, $preco, $usuarios_id]);
    echo json_encode(['success' => true]);
} elseif ($action === 'update') {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $quantidade = $_POST['quantidade'];
    $preco = $_POST['preco'];
    $adquirido = $_POST['adquirido'];

    $sql = 'UPDATE itens SET nome = ?, quantidade = ?, preco = ?, adquirido = ? WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nome, $quantidade, $preco, $adquirido, $id]);
    echo json_encode(['success' => true]);
} elseif ($action === 'delete') {
    $id = $_POST['id'];

    $sql = 'DELETE FROM itens WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    echo json_encode(['success' => true]);
}
?>
