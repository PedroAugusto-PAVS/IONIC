<?php
include 'conexao.php';

header('Content-Type: application/json');

$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = 'SELECT * FROM usuarios WHERE email = ?';
$stmt = $pdo->prepare($sql);
$stmt->execute([$email]);
$usuarios = $stmt->fetch(PDO::FETCH_ASSOC);

if ($usuarios && password_verify($senha, $usuarios['senha'])) {
    echo json_encode(['success' => true, 'usuarios_id' => $usuarios['id']]);
} else {
    echo json_encode(['success' => false]);
}
?>
