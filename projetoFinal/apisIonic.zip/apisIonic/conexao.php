<?php

$banco = 'dmprojetofinal';
$host = 'localhost';
$usuario = 'root';
$senha = '';

    try {
        //require_once 'config.php';
        //$conn = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
        $conn = new PDO("mysql:dbname=$banco;host=$host", "$usuario", "$senha");
    } catch (Exception $e) {
        echo $e->getMessage();
        echo "<br>";
        echo $e->getCode();
    }
?>