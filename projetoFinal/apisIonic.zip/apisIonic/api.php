<?php

header('Access-Control-Allow-Origin: *');

require 'conexao.php';

$data = filter_input(INPUT_POST, 'data', FILTER_DEFAULT);
$result = [];

if ($data) {
    // Transforma o json em array
    $data = json_decode($data);

    try {
        switch ($data->action) {

            case 'logar':
                $email = $data->email;
                $senha = $data->senha;

                $sql = "SELECT * FROM usuarios WHERE email = :email";
                $query = $conn->prepare($sql);
                $query->bindValue(':email', $email);

                if ($query->execute()){
                    $usuario = $query->fetch(PDO::FETCH_ASSOC);
                    if ($usuario && password_verify($senha, $usuario['senha'])) { //depois de arrumar tudo aivar o verify
                        $result = array('ok' => true, 'status' => '200', 'message' => 'Login efetuado com sucesso!', 'user' => $usuario);
                    } else {
                        $result = array('ok' => false, 'status' => '401', 'message' => 'Email e/ou senha inválidos!');
                    }
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao fazer login');
                }
                break;

            case 'criarConta':
                $nome = $data->nome;
                $email = $data->email;
                $senha = $data->senha;

                $senhaCriptografada = password_hash($senha, PASSWORD_BCRYPT);

                try {
                    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)";
                    $query = $conn->prepare($sql);
                    $query->bindValue(':nome', $nome);
                    $query->bindValue(':email', $email);
                    $query->bindValue(':senha', $senhaCriptografada);
                    $query->execute();

                    $result = array('ok' => true, 'status' => '200', 'message' => 'Conta criada com sucesso!');
                } catch (PDOException) {
                    if ($e->errorInfo[1] == 1062) {  // Código de erro 1062 significa duplicidade de chave única
                        $result = array('ok' => false, 'status' => '409', 'message' => 'Email já cadastrado!');
                    } else {
                        $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao criar conta!');
                    }
                }
                break;
            
            case 'cadastrarProduto':
                $produto = $data->produto;
                $quantidade = $data->qtd;
                $preco = $data->preco;

                $sql = "INSERT INTO produtos (nome_produto, quant, valor) VALUES (:produto, :quantidade, :preco)";
                $query = $conn->prepare($sql);
                $query->bindValue(':produto', $produto);
                $query->bindValue(':quantidade', $quantidade);
                $query->bindValue(':preco', $preco);
                
                if($query->execute()) {
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Produto cadastrado com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Houve um erro no servidor!');
                }
                break;
            
            case 'verificarEmail':
                $email = $data->email;

                $sql = "SELECT COUNT(*) as count FROM usuarios WHERE email = :email";
                $query = $conn->prepare($sql);
                $query->bindValue(':email', $email);

                if ($query->execute()) {
                    $count = $query->fetch(PDO::FETCH_ASSOC)['count'];
                    $result = array('ok' => true, 'emailExiste' => $count > 0);
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao verificar email');
                }
                break;

            case 'listarItens':
                $sql = "SELECT * FROM produtos";
                $query = $conn->prepare($sql);

                if ($query->execute()) {
                    $res = $query->fetchAll(PDO::FETCH_ASSOC);
                    $itensGeral = count($res);

                    for ($i = 0; $i < count($res); $i++) {
                        foreach ($res[$i] as $key => $value) {
                        }
                        $dados[] = array (
                            'id' => $res[$i]['id'],
                            'nome' => $res[$i]['nome_produto'],
                            'quant' => $res[$i]['quant'],
                            'valor' => $res[$i]['valor']
                        );
                    }

                    $result = array('ok' => true, 'status' => '200', 'result' => $dados, 'total' => $itensGeral, 'message' => 'Listagem realizada com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Algo de errado no servidor!');
                }
                break;

            case 'atualizarStatusAdquirido':
                $id = $data->id;
                $adquirido = $data->adquirido; //aqui recebe o status do produto

                $sql = "UPDATE produtos SET adquirido = :adquirido WHERE id = :id";
                $query = $conn->prepare($sql);
                $query->bindValue(':adquirido', $adquirido, PDO::PARAM_BOOL);
                $query->bindValue(':id', $id, PDO::PARAM_INT);

                if ($query->execute()) {
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Status do item atualizado com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao atualizar o status ');
                }
                break;

            case 'excluirProduto':
                $id = $data->id;
                $sql = "delete from produtos where id = :id";
                $query = $conn->prepare($sql);
                $query->bindValue(':id',$id);
                if ($query->execute()){
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Produto excluído com sucesso');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao excluir produto');
                }
                break;

            case 'atualizarProduto':
                $sql = "UPDATE produtos SET nome_produto = :nomeProduto, quant = :quantidade, valor = :valor WHERE id = :id";
                $query = $conn->prepare($sql);
                $query->bindValue(':nomeProduto', $data->nomeProduto);
                $query->bindValue(':quant', $data->quantidade);
                $query->bindValue(':valor', $data->valor);
                $query->bindValue(':id', $data->id, PDO::PARAM_INT);

                if($query->execute()) {
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Produto atualizado com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao atualizar produto!');
                }
                break;

            /*case 'inserirProduto':
                $sql = "insert into produtos (nome) values (:nomeProduto)";
                $query = $conn->prepare($sql);
                $query->bindValue(':nomeProduto', $data->nomeProduto);
                if ($query->execute()) {
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Produto inserido com sucesso');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Algo de errado no servidor!');
                }
                break;

            case 'listarProdutos':
                $sql = "select * from produtos";
                $query = $conn->prepare($sql);

                if ($query->execute()) {
                    
                    $res = $query->fetchAll(PDO::FETCH_ASSOC);
                    $totalItens = count($res);

                    for ($i = 0; $i < count($res); $i++) {
                        foreach ($res[$i] as $key => $value) {
                        }
                        $dados[] = array(
                            'id' => $res[$i]['id'],
                            'nome' => $res[$i]['nome']
                        );
                    }
                        

                    $result = array('ok' => true, 'status' => '200', 'result'=>$dados, 'total'=>$totalItens,'message' => 'Listagem realizada com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Algo de errado no servidor!');
                }
                break;

            case 'excluirProduto':
                $id = $data->id;
                $sql = "delete from produtos where id = :id";
                $query = $conn->prepare($sql);
                $query->bindValue(':id',$id);
                if ($query->execute()){
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Produto excluído com sucesso');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao excluir produto');
                }
                break;

            case 'buscarProduto':
                $sql = "SELECT * FROM produtos WHERE id = :id";
                $query = $conn->prepare($sql);
                $query->bindValue(':id', $data->id);
                if ($query->execute()) {
                    $produto = $query->fetch(PDO::FETCH_ASSOC);
                    $result = array('ok' => true, 'status' => '200', 'result' => $produto, 'message' => 'Produto encontrado com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao buscar produto!');
                }
                break;

            case 'atualizarProduto':
                $sql = "UPDATE produtos SET nome = :nomeProduto WHERE id = :id";
                $query = $conn->prepare($sql);
                $query->bindValue(':nomeProduto', $data->nomeProduto);
                $query->bindValue(':id', $data->id, PDO::PARAM_INT);
                if ($query->execute()) {
                    $result = array('ok' => true, 'status' => '200', 'message' => 'Produto atualizado com sucesso!');
                } else {
                    $result = array('ok' => false, 'status' => '500', 'message' => 'Erro ao atualizar produto!');
                }
                break;*/

            default:
                $result = array('ok' => true, 'status' => '200', 'message' => 'case default');
                break;
        }
    } catch (Exception $ex) {
        $result = array('ok' => false, 'status' => '500', 'message' => $ex);
    }
} else {
    $result = array('ok' => true, 'status' => '200', 'message' => 'erro');
}

echo json_encode($result);
